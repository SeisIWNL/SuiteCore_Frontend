<template>
  <aside class="sidebar" :class="{ 'sidebar--collapsed': !mainStore.sidebarOpen }">

    <!-- Logo -->
    <div class="sidebar__logo">
      <div class="sidebar__logo-mark">
        <svg width="28" height="28" viewBox="0 0 42 42" fill="none">
          <path d="M8 1h26l7 7v26l-7 7H8L1 34V8L8 1z"
            fill="none" stroke="var(--accent)" stroke-width="1.2"/>
          <text x="21" y="26" text-anchor="middle"
            font-family="'Syne', sans-serif"
            font-weight="800" font-size="14"
            fill="var(--accent)" letter-spacing="-1">SC</text>
        </svg>
      </div>
      <Transition name="fade-label">
        <div v-if="mainStore.sidebarOpen" class="sidebar__logo-text">
          <span class="sidebar__logo-name">SuiteCore</span>
          <span class="sidebar__logo-sub">NOC</span>
        </div>
      </Transition>
    </div>

    <!-- Nav -->
    <nav class="sidebar__nav">
      <div v-for="group in navGroups" :key="group.label">
        <Transition name="fade-label">
          <div v-if="mainStore.sidebarOpen" class="sidebar__group-label">
            {{ group.label }}
          </div>
          <div v-else class="sidebar__group-divider" />
        </Transition>

        <RouterLink
          v-for="item in group.items"
          :key="item.to"
          :to="item.to"
          class="sidebar__item"
          :class="{ 'sidebar__item--active': isActive(item.to) }"
          :title="!mainStore.sidebarOpen ? item.label : undefined"
        >
          <span class="sidebar__item-icon" v-html="item.icon" />
          <Transition name="fade-label">
            <span v-if="mainStore.sidebarOpen" class="sidebar__item-label">
              {{ item.label }}
            </span>
          </Transition>
          <Transition name="fade-label">
            <span
              v-if="mainStore.sidebarOpen && item.badge"
              class="sidebar__item-badge"
              :class="`sidebar__item-badge--${item.badgeType}`"
            >{{ item.badge }}</span>
          </Transition>
        </RouterLink>
      </div>
    </nav>

    <!-- Usuario + logout -->
    <div class="sidebar__footer">
      <div class="sidebar__user">
        <div class="sidebar__user-avatar">{{ userInitials }}</div>
        <Transition name="fade-label">
          <div v-if="mainStore.sidebarOpen" class="sidebar__user-info">
            <span class="sidebar__user-name">{{ fullName }}</span>
            <span class="sidebar__user-role">{{ user?.username }}</span>
          </div>
        </Transition>
      </div>
      <Transition name="fade-label">
        <button v-if="mainStore.sidebarOpen" class="sidebar__logout" @click="handleLogout">
          <svg width="13" height="13" viewBox="0 0 24 24" fill="none"
            stroke="currentColor" stroke-width="2"
            stroke-linecap="round" stroke-linejoin="round">
            <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/>
            <polyline points="16 17 21 12 16 7"/>
            <line x1="21" y1="12" x2="9" y2="12"/>
          </svg>
        </button>
      </Transition>
    </div>

    <!-- Collapse toggle -->
    <button class="sidebar__toggle" @click="mainStore.toggleSidebar">
      <svg width="12" height="12" viewBox="0 0 24 24" fill="none"
        stroke="currentColor" stroke-width="2.5"
        stroke-linecap="round" stroke-linejoin="round">
        <polyline v-if="mainStore.sidebarOpen" points="15 18 9 12 15 6"/>
        <polyline v-else points="9 18 15 12 9 6"/>
      </svg>
    </button>

  </aside>
</template>

<script setup>
import { computed } from 'vue'
import { RouterLink, useRoute, useRouter } from 'vue-router'
import { useAuthStore } from '@/modules/auth/store.js'
import { useMainStore } from '@/modules/main/store.js'

const authStore = useAuthStore()
const mainStore = useMainStore()
const route     = useRoute()
const router    = useRouter()

const user         = computed(() => authStore.user)
const userInitials = computed(() => authStore.userInitials || 'US')
const fullName     = computed(() => {
  const u = authStore.user
  if (!u) return ''
  return [u.firstName, u.lastName].filter(Boolean).join(' ') || u.username
})

const navGroups = [
  {
    label: 'General',
    items: [
      {
        to: '/dashboard', label: 'Dashboard', badge: null,
        icon: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="7" height="7"/><rect x="14" y="3" width="7" height="7"/><rect x="14" y="14" width="7" height="7"/><rect x="3" y="14" width="7" height="7"/></svg>`
      },
    ]
  },
  {
    label: 'Monitoreo',
    items: [
      {
        to: '/servers', label: 'Servidores', badge: '2', badgeType: 'danger',
        icon: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="2" y="2" width="20" height="8" rx="2"/><rect x="2" y="14" width="20" height="8" rx="2"/><line x1="6" y1="6" x2="6.01" y2="6"/><line x1="6" y1="18" x2="6.01" y2="18"/></svg>`
      },
      {
        to: '/network', label: 'Red', badge: null,
        icon: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="9" y="2" width="6" height="6"/><rect x="9" y="16" width="6" height="6"/><rect x="2" y="9" width="6" height="6"/><rect x="16" y="9" width="6" height="6"/><line x1="12" y1="8" x2="12" y2="16"/><line x1="8" y1="12" x2="16" y2="12"/></svg>`
      },
      {
        to: '/alerts', label: 'Alertas', badge: '5', badgeType: 'warning',
        icon: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"/><path d="M13.73 21a2 2 0 0 1-3.46 0"/></svg>`
      },
    ]
  },
  {
    label: 'Auditoría',
    items: [
      {
        to: '/logs', label: 'Logs', badge: null,
        icon: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"/><polyline points="14 2 14 8 20 8"/><line x1="16" y1="13" x2="8" y2="13"/><line x1="16" y1="17" x2="8" y2="17"/></svg>`
      },
    ]
  },
  {
    label: 'Configuración',
    items: [
      {
        to: '/settings', label: 'Ajustes', badge: null,
        icon: `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><circle cx="12" cy="12" r="3"/><path d="M19.4 15a1.65 1.65 0 0 0 .33 1.82l.06.06a2 2 0 0 1-2.83 2.83l-.06-.06a1.65 1.65 0 0 0-1.82-.33 1.65 1.65 0 0 0-1 1.51V21a2 2 0 0 1-4 0v-.09A1.65 1.65 0 0 0 9 19.4a1.65 1.65 0 0 0-1.82.33l-.06.06a2 2 0 0 1-2.83-2.83l.06-.06A1.65 1.65 0 0 0 4.68 15a1.65 1.65 0 0 0-1.51-1H3a2 2 0 0 1 0-4h.09A1.65 1.65 0 0 0 4.6 9a1.65 1.65 0 0 0-.33-1.82l-.06-.06a2 2 0 0 1 2.83-2.83l.06.06A1.65 1.65 0 0 0 9 4.68a1.65 1.65 0 0 0 1-1.51V3a2 2 0 0 1 4 0v.09a1.65 1.65 0 0 0 1 1.51 1.65 1.65 0 0 0 1.82-.33l.06-.06a2 2 0 0 1 2.83 2.83l-.06.06A1.65 1.65 0 0 0 19.4 9a1.65 1.65 0 0 0 1.51 1H21a2 2 0 0 1 0 4h-.09a1.65 1.65 0 0 0-1.51 1z"/></svg>`
      },
    ]
  },
]

function isActive(to) {
  return route.path === to || (to === '/dashboard' && route.path === '/dashboard')
}

async function handleLogout() {
  await authStore.logout()
  router.push({ name: 'login' })
}
</script>

<style scoped>
.sidebar {
  width: 220px;
  height: 100vh;
  background: var(--bg-1);
  border-right: 1px solid var(--border);
  display: flex;
  flex-direction: column;
  position: fixed;
  top: 0; left: 0;
  z-index: 100;
  transition: width .22s cubic-bezier(.4,0,.2,1);
  overflow: hidden;
}
.sidebar--collapsed { width: 56px; }

/* Logo */
.sidebar__logo {
  display: flex;
  align-items: center;
  gap: 10px;
  height: 56px;
  padding: 0 14px;
  border-bottom: 1px solid var(--border);
  flex-shrink: 0;
  overflow: hidden;
}
.sidebar__logo-mark {
  flex-shrink: 0;
  filter: drop-shadow(0 0 8px rgba(57,211,83,.25));
}
.sidebar__logo-text { display: flex; flex-direction: column; gap: 1px; white-space: nowrap; }
.sidebar__logo-name {
  font-family: var(--font-display);
  font-size: .9rem;
  font-weight: 800;
  color: var(--text-1);
  letter-spacing: -.3px;
  line-height: 1;
}
.sidebar__logo-sub {
  font-size: .6rem;
  color: var(--accent);
  letter-spacing: .12em;
  text-transform: uppercase;
}

/* Nav */
.sidebar__nav {
  flex: 1;
  padding: 10px 8px;
  overflow-y: auto;
  overflow-x: hidden;
  display: flex;
  flex-direction: column;
  gap: 2px;
}
.sidebar__group-label {
  font-size: .6rem;
  font-weight: 700;
  color: var(--text-3);
  letter-spacing: .1em;
  text-transform: uppercase;
  padding: 10px 8px 4px;
  white-space: nowrap;
}
.sidebar__group-divider {
  height: 1px;
  background: var(--border);
  margin: 8px 4px 6px;
}

.sidebar__item {
  display: flex;
  align-items: center;
  gap: 10px;
  padding: 8px 8px;
  border-radius: var(--radius);
  color: var(--text-2);
  text-decoration: none;
  font-size: .82rem;
  transition: background .12s, color .12s;
  white-space: nowrap;
  position: relative;
  overflow: hidden;
}
.sidebar__item:hover { background: var(--bg-hover); color: var(--text-1); }
.sidebar__item--active {
  background: var(--accent-muted);
  color: var(--accent);
  border: 1px solid rgba(57,211,83,.15);
}
.sidebar__item--active .sidebar__item-icon { color: var(--accent); }

.sidebar__item-icon {
  flex-shrink: 0;
  width: 20px;
  display: flex; align-items: center; justify-content: center;
}
.sidebar__item-label { flex: 1; }
.sidebar__item-badge {
  font-size: .6rem; font-weight: 700;
  padding: 1px 5px;
  border-radius: 99px;
  flex-shrink: 0;
}
.sidebar__item-badge--danger  { background: var(--danger-muted);  color: var(--danger); }
.sidebar__item-badge--warning { background: var(--warning-muted); color: var(--warning); }

/* Footer */
.sidebar__footer {
  border-top: 1px solid var(--border);
  padding: 10px 10px;
  display: flex;
  align-items: center;
  gap: 8px;
  flex-shrink: 0;
  overflow: hidden;
}
.sidebar__user {
  display: flex; align-items: center; gap: 8px; flex: 1; overflow: hidden;
}
.sidebar__user-avatar {
  width: 28px; height: 28px;
  border-radius: 50%;
  background: linear-gradient(135deg, var(--accent-dim), #2563eb);
  display: flex; align-items: center; justify-content: center;
  font-size: .65rem; font-weight: 700; color: var(--bg);
  flex-shrink: 0;
}
.sidebar__user-info { overflow: hidden; display: flex; flex-direction: column; gap: 1px; }
.sidebar__user-name {
  font-size: .75rem; font-weight: 600;
  color: var(--text-1); white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.sidebar__user-role {
  font-size: .65rem; color: var(--text-3);
  white-space: nowrap; overflow: hidden; text-overflow: ellipsis;
}
.sidebar__logout {
  flex-shrink: 0;
  background: none; border: none;
  color: var(--text-3); cursor: pointer; padding: 4px;
  border-radius: var(--radius-sm); transition: color .12s, background .12s;
}
.sidebar__logout:hover { color: var(--danger); background: var(--danger-muted); }

/* Toggle */
.sidebar__toggle {
  position: absolute;
  top: 50%; right: 0;
  transform: translateY(-50%);
  width: 16px; height: 32px;
  background: var(--bg-2);
  border: 1px solid var(--border);
  border-right: none;
  border-radius: 4px 0 0 4px;
  color: var(--text-3);
  cursor: pointer;
  display: flex; align-items: center; justify-content: center;
  transition: color .12s, background .12s;
  opacity: 0;
}
.sidebar:hover .sidebar__toggle { opacity: 1; }
.sidebar__toggle:hover { color: var(--text-1); background: var(--bg-3); }

/* Transitions */
.fade-label-enter-active { transition: opacity .18s .05s, transform .18s .05s; }
.fade-label-leave-active { transition: opacity .1s, transform .1s; }
.fade-label-enter-from, .fade-label-leave-to { opacity: 0; transform: translateX(-6px); }
</style>
